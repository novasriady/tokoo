<?php $__env->startSection('title', 'Order'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-col gap-4">
        <div class="flex flex-col">
            <h1 class="text-lg font-semibold">Order</h1>
            <div class="text-sm breadcrumbs">
                <ul>
                    <li>
                        <a>Admin</a>
                    </li>
                    <li>
                        <a>Order</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="card bg-white">
            <div class="card-body">
                <div class="overflow-x-auto">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Total Payment</th>
                                <th>Shipping Service</th>
                                <th>Address</th>
                                <th>Order Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($orders === null): ?>
                                <p class="text-sm text-error text-center">There is no order data.</p>
                            <?php else: ?>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="transition-all duration-300 cursor-pointer hover:bg-gray-200"
                                        onclick="document.getElementById('my_modal_<?php echo e($order->order_id); ?>').showModal()">
                                        <th><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($order->user->firstname); ?> <?php echo e($order->user->lastname); ?></td>
                                        <td>IDR <?php echo e(number_format($order->order_totalpayment, 0, ',', '.')); ?></td>
                                        <td><?php echo e($order->order_shippingservice); ?></td>
                                        <td><?php echo e($order->order_address); ?></td>
                                        <td>
                                            <?php if($order->order_status === 'Unpaid'): ?>
                                                <div class="badge badge-sm badge-error text-white">Unpaid</div>
                                            <?php elseif($order->order_status === 'Pending Approval'): ?>
                                                <div class="badge badge-sm badge-warning text-white">Pending</div>
                                            <?php elseif($order->order_status === 'Approved'): ?>
                                                <div class="badge badge-sm badge-info text-white">Waiting</div>
                                            <?php elseif($order->order_status === 'Rejected'): ?>
                                                <div class="badge badge-sm badge-error text-white">Rejected</div>
                                            <?php elseif($order->order_status === 'Retrieved'): ?>
                                                <div class="badge badge-sm badge-info text-white">Retrieved</div>
                                            <?php elseif($order->order_status === 'Sent'): ?>
                                                <div class="badge badge-sm badge-success text-white">Sent</div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <dialog id="my_modal_<?php echo e($order->order_id); ?>" class="modal">
                                        <div class="modal-box">
                                            <div class="flex items-center justify-between">
                                                <div class="flex items-center gap-4">
                                                    <h3 class="font-semibold text-lg">Order Details</h3>
                                                    <?php if($order->order_status === 'Unpaid'): ?>
                                                        <div class="badge badge-sm badge-error text-white">Unpaid</div>
                                                    <?php elseif($order->order_status === 'Pending Approval'): ?>
                                                        <div class="badge badge-sm badge-warning text-white">Pending
                                                            Approval
                                                        </div>
                                                    <?php elseif($order->order_status === 'Approved'): ?>
                                                        <div class="badge badge-sm badge-info text-white">Waiting for Delivery</div>
                                                    <?php elseif($order->order_status === 'Rejected'): ?>
                                                        <div class="badge badge-sm badge-error text-white">Rejected</div>
                                                    <?php elseif($order->order_status === 'Retrieved'): ?>
                                                        <div class="badge badge-sm badge-info text-white">Retrieved</div>
                                                    <?php elseif($order->order_status === 'Sent'): ?>
                                                        <div class="badge badge-sm badge-success text-white">Sent</div>
                                                    <?php endif; ?>
                                                </div>
                                                <form method="dialog">
                                                    <button class="btn btn-sm btn-ghost">
                                                        <i class="fa-solid fa-xmark"></i>
                                                    </button>
                                                </form>
                                            </div>
                                            <div class="divider my-0 mb-4"></div>
                                            <div class="flex flex-col gap-4">
                                                <div class="grid grid-cols-3 gap-y-6 gap-x-6">
                                                    <div class="flex flex-col gap-1 h-fit">
                                                        <p class="text-sm font-medium">Name</p>
                                                        <p class="text-sm"><?php echo e($order->user->firstname); ?>

                                                            <?php echo e($order->user->lastname); ?></p>
                                                    </div>
                                                    <div class="flex flex-col gap-1 h-fit">
                                                        <p class="text-sm font-medium">Total Payment</p>
                                                        <p class="text-sm">IDR
                                                            <?php echo e(number_format($order->order_totalpayment, 0, ',', '.')); ?>

                                                        </p>
                                                    </div>
                                                    <div class="flex flex-col gap-1 h-fit">
                                                        <p class="text-sm font-medium">Shipping Service</p>
                                                        <p class="text-sm"><?php echo e($order->order_shippingservice); ?></p>
                                                    </div>
                                                    <div class="flex flex-col gap-1 h-fit">
                                                        <p class="text-sm font-medium">Address</p>
                                                        <p class="text-sm"><?php echo e($order->order_address); ?></p>
                                                    </div>
                                                    <div class="flex flex-col gap-1 h-fit">
                                                        <p class="text-sm font-medium">Proof of Payment</p>
                                                        <?php if($order->order_status !== 'Unpaid'): ?>
                                                            <div
                                                                class="border border-gray-200 w-fit rounded-md overflow-hidden">
                                                                <img src="<?php echo e(asset('storage/' . $order->order_proofpayment)); ?>"
                                                                    class="w-24" alt="Proof Payment Image">
                                                            </div>
                                                        <?php else: ?>
                                                            <p class="text-sm text-error">User has not made a payment.</p>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="flex flex-col gap-1 h-fit">
                                                        <p class="text-sm font-medium text-error">Rejected Notes</p>
                                                        <p class="text-sm">
                                                            <?php echo e($order->order_rejectednotes ? $order->order_rejectednotes : '-'); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="divider my-4"></div>
                                            <div class="flex flex-col">
                                                <p class="text-sm font-medium">Order Details</p>
                                                <?php $__currentLoopData = $order->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="flex gap-6 items-center py-4 border-b border-gray-200">
                                                        <div class="rounded w-12 overflow-hidden">
                                                            <img src="<?php echo e(asset('storage/' . $orderDetail->product->product_img)); ?>"
                                                                alt="Product Image">
                                                        </div>
                                                        <div class="block">
                                                            <p class="font-medium text-sm">
                                                                <?php echo e($orderDetail->product->product_name); ?></p>
                                                            <p class="text-xs mt-1 mb-3">
                                                                <?php echo e($orderDetail->product->category->category_name); ?></p>
                                                            <p class="text-sm">
                                                                <span class="font-medium">Quantity</span>:
                                                                <?php echo e($orderDetail->detail_quantity); ?>

                                                                |
                                                                <span class="font-medium">Total Price</span>: IDR
                                                                <?php echo e(number_format($orderDetail->detail_totalprice, 0, ',', '.')); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php if($order->order_status !== 'Unpaid'): ?>
                                                <div class="mt-4">
                                                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.order.update-order-form', ['orderId' => $order->order_id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1127640024-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </dialog>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/pages/admin/order.blade.php ENDPATH**/ ?>