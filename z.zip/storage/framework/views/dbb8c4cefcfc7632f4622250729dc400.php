<div class="modal" role="dialog" id="my_modal_8">
    <div class="modal-box">
        <h3 class="font-bold text-lg">Hello!</h3>
        <p class="py-4">This modal works with anchor links</p>
        <div class="modal-action">
            <a href="#" class="btn">Yay!</a>
        </div>
    </div>
</div>
<?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/livewire/admin/order/order-details.blade.php ENDPATH**/ ?>