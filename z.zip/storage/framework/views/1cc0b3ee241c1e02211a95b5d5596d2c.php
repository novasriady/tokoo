<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="hero min-h-screen"
        style="background-image: url('<?php echo e(asset('assets/img/hero1.jpg')); ?>');">
        <div class="hero-overlay bg-opacity-60"></div>
        <div class="hero-content text-center text-neutral-content">
            <div class="max-w-md">
                <h1 class="mb-5 text-5xl font-bold">Welcome to Thrift</h1>
                <p class="mb-5">A place where you can buy a wide range of today's fashion products at cheap and affordable prices.</p>
                <a href="#productSection" class="btn bg-gray-800 text-white border-none btn-sm">Check Our Product Now</a>
            </div>
        </div>
    </div>
    
    <section class="mt-20 w-full px-12" id="productSection">
        <div class="flex flex-col gap-8">
            <div class="flex flex-col gap-2">
                <h1 class="font-semibold text-2xl">Our Product</h1>
                <p>Choose the product you want now!</p>
            </div>
            <div class="grid grid-cols-4 gap-x-6 gap-y-8">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card card-compact w-full bg-white rounded-xl shadow-md">
                        <figure class="h-56 overflow-hidden">
                            <img src="<?php echo e(asset('storage/' . $product->product_img)); ?>" alt="Product Image" class="w-full" />
                        </figure>
                        <div class="card-body">
                            <h2 class="card-title"><?php echo e($product->product_name); ?></h2>
                            <p><?php echo e($product->product_description); ?></p>
                            <div class="card-actions justify-start mt-2">
                                <a href="<?php echo e(route('user.productDetails', ['product_id' => $product->product_id])); ?>" class="btn bg-gray-800 text-white btn-sm">Check Now</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    
    <section class="mt-20 w-full px-12">
        <div class="flex flex-col gap-8">
            <div class="flex flex-col gap-2">
                <h1 class="font-semibold text-2xl">Product Categories</h1>
                <p>A wide variety of product categories to choose from.</p>
            </div>
            <div class="grid grid-cols-4 gap-x-6 gap-y-8">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card w-full h-52 bg-white rounded-xl shadow-md image-full">
                        <figure>
                            <img src="<?php echo e(asset('/storage/' . $category->category_img)); ?>" alt="Shoes" />
                        </figure>
                        <div class="card-body">
                            <h2 class="card-title"><?php echo e($category->category_name); ?></h2>
                            <p><?php echo e($category->category_description); ?></p>
                            <div class="card-actions justify-start mt-2">
                                <a href="<?php echo e(route('user.product')); ?>" class="btn bg-gray-800 text-white btn-sm border-none">Check Now</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/pages/user/home.blade.php ENDPATH**/ ?>