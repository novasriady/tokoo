<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <section class="my-8 w-full px-12">
        <div class="flex">
            <div class="w-1/4 h-fit px-4 py-4 bg-white shadow-md rounded-lg">
                <div class="flex flex-col">
                    <p class="font-semibold">Product Filter</p>
                    <div class="divider my-2"></div>
                    <div class="flex flex-col gap-4">
                        <select class="select select-bordered w-full max-w-xs">
                            <option disabled selected>Category</option>
                            <option>Man's Clothing</option>
                            <option>Women's Clothing</option>
                            <option>Shoes</option>
                        </select>
                        <select class="select select-bordered w-full max-w-xs">
                            <option disabled selected>Price Range</option>
                            <option>Rp50.000 - Rp150.000</option>
                            <option>Rp150.000 - Rp300.000</option>
                            <option>Rp300.000 - Rp500.000</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="w-3/4 pl-12">
                <div class="grid grid-cols-4 gap-x-6 gap-y-6">
                    <div class="card card-compact w-full bg-white shadow-md rounded-lg">
                        <figure>
                            <img src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg"alt="Shoes" />
                        </figure>
                        <div class="card-body">
                            <p class="text-lg font-semibold">Shoes</p>
                            <p>If a dog chews shoes whose shoes does he choose?</p>
                            <div class="card-actions justify-start mt-2">
                                <button class="btn bg-gray-800 text-white btn-sm">See Details</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/livewire/user/products.blade.php ENDPATH**/ ?>