<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="card bg-white shadow-md rounded-xl h-fit w-[22rem]">
    <div class="card-body">
        <h1 class="font-semibold text-lg">Thrift Login</h1>
        <div class="divider my-0"></div>
        <form action="<?php echo e(route('auth.loginAction')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="flex flex-col gap-4">
                <div class="flex flex-col gap-2">
                    <label class="label-text">Username</label>
                    <input type="text" placeholder="Username" name="username" class="input input-bordered input-sm w-full" required>
                </div>
                <div class="flex flex-col gap-2">
                    <label class="label-text">Password</label>
                    <input type="password" placeholder="Password" name="password" class="input input-bordered input-sm w-full" required>
                </div>
                <button type="submit" class="btn btn-sm bg-gray-800 text-white">Login</button>
            </div>
        </form>
        <div class="mt-6">
            <p class="text-sm text-center">
                Don't have account? 
                <a href="<?php echo e(route('auth.register')); ?>" class="underline text-blue-600">Register now</a>
            </p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/pages/auth/login.blade.php ENDPATH**/ ?>