<?php $__env->startSection('title', 'Product'); ?>

<?php $__env->startSection('content'); ?>
    <div class="px-12 my-8">
        <div class="grid grid-cols-2 gap-x-8">
            <div class="card bg-white shadow-md rounded-xl h-fit">
                <div class="card-body">
                    <div class="flex items-center gap-x-6">
                        <img src="<?php echo e(asset('storage/' . $product->product_img)); ?>" alt="Product Image" class="rounded-xl w-64">
                        <div class="flex flex-col gap-4">
                            <div class="flex flex-col gap-1">
                                <h1 class="font-semibold text-lg"><?php echo e($product->product_name); ?></h1>
                                <p class="text-sm">
                                    <?php echo e($product->category->category_name); ?> | 
                                    <span class="font-semibold"><?php echo e($product->product_stock); ?> Stock Available</span>
                                </p>
                                <p class="text-sm"><?php echo e($product->product_description); ?></p>
                            </div>
                            <p class="font-medium">IDR <?php echo e(number_format($product->product_price, 0, ',', '.')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.purchase-details', ['product' => $product]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2005722513-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/pages/user/product/details.blade.php ENDPATH**/ ?>