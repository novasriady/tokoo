<?php $__env->startSection('title', 'Cart'); ?>

<?php $__env->startSection('content'); ?>
    <div class="px-12 my-8">
        <div class="grid grid-cols-2 gap-x-6">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.payment.payment-list', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-971302015-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.payment.payment-details', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-971302015-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/pages/user/payment.blade.php ENDPATH**/ ?>