<div class="card bg-white shadow-md rounded-xl h-fit">
    <div class="card-body">
        <h1 class="font-semibold text-lg">Carts</h1>
        <div class="divider my-0"></div>
        <!--[if BLOCK]><![endif]--><?php if(count($cart) === 0 || count($cart['order_details']) === 0): ?>
            <p class="text-sm text-error">Cart data is still empty. Please make a product purchase to fill your
                cart.</p>
        <?php else: ?>
            <div class="flex flex-col gap-2">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cart['order_details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between py-4 border-b border-gray-200">
                        <div class="flex gap-6 items-center">
                            <div class="rounded h-20 w-20 overflow-hidden">
                                <img src="<?php echo e(asset('storage/' . $orderDetail['detail_product_img'])); ?>" alt="Product Image">
                            </div>
                            <div class="block">
                                <p class="font-medium"><?php echo e($orderDetail['detail_product_name']); ?></p>
                                <p class="text-sm mt-1 mb-3"><?php echo e($orderDetail['detail_product_category']); ?></p>
                                <p class="text-sm">
                                    <span class="font-medium">Quantity</span>: <?php echo e($orderDetail['detail_quantity']); ?> | 
                                    <span class="font-medium">Total Price</span>: IDR <?php echo e(number_format($orderDetail['detail_totalprice'], 0, ',', '.')); ?></p>
                            </div>
                        </div>
                        <button class="btn btn-error btn-sm text-white" wire:click="deleteProductFromCart('<?php echo e($orderDetail['detail_id']); ?>')">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/livewire/user/cart/cart-list.blade.php ENDPATH**/ ?>