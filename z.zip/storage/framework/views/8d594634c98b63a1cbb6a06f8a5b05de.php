<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body>
    <p class="text-3xl font-bold underline text-red-600">Hello world!</p>
</body>

</html><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/welcome.blade.php ENDPATH**/ ?>