<div class="card bg-white shadow-md rounded-xl h-fit">
    <div class="card-body">
        <div class="flex items-center justify-between">
            <h1 class="font-semibold">Payment Details</h1>
            <!--[if BLOCK]><![endif]--><?php if($order !== null): ?>
                <!--[if BLOCK]><![endif]--><?php if($order->order_status === 'Unpaid'): ?>
                    <div class="badge badge-sm badge-error text-white">Unpaid</div>
                <?php elseif($order->order_status === 'Pending Approval'): ?>
                    <div class="badge badge-sm badge-warning text-white">Pending Approval
                    </div>
                <?php elseif($order->order_status === 'Approved'): ?>
                    <div class="badge badge-sm badge-info text-white">Waiting for Delivery
                    </div>
                <?php elseif($order->order_status === 'Rejected'): ?>
                    <div class="badge badge-sm badge-error text-white">Rejected</div>
                <?php elseif($order->order_status === 'Retrieved'): ?>
                    <div class="badge badge-sm badge-info text-white">Retrieved</div>
                <?php elseif($order->order_status === 'Sent'): ?>
                    <div class="badge badge-sm badge-success text-white">Sent</div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="divider my-0"></div>
        <!--[if BLOCK]><![endif]--><?php if($order === null): ?>
            <p class="text-sm text-error text-center">No order data is selected.</p>
        <?php else: ?>
            <!--[if BLOCK]><![endif]--><?php if($order->order_status === 'Unpaid'): ?>
                <div class="flex flex-col gap-4">
                    <div role="alert" class="alert">
                        <div class="flex items-center gap-6">
                            <i class="fa-solid fa-money-check"></i>
                            <div class="flex flex-col gap-1">
                                <p class="text-sm">Please make payment to one of the following bank accounts and upload
                                    proof
                                    of payment.</p>
                                <p>
                                    <span class="font-medium text-sm">BANK MANDIRI</span>: SATYA MAHENDRA 1234567
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="flex flex-col gap-2">
                        <label class="label-text">Proof of Payment</label>
                        <input type="file" class="file-input file-input-bordered file-input-sm  w-full" wire:model="proofPayment">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['proofPayment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-error text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <span wire:loading wire:target="payOrder">
                        <button class="btn btn-sm text-white bg-gray-800 w-full" disabled>
                            <span class="loading loading-spinner"></span>
                            Loading...
                        </button>
                    </span>
                    <span wire:loading.remove wire:target="payOrder">
                        <button class="btn btn-sm text-white bg-gray-800 w-full" wire:click="payOrder('<?php echo e($order->order_id); ?>')">Pay Order</button>
                    </span>
                </div>
                <div class="divider my-0"></div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <div class="grid grid-cols-3 gap-x-4 gap-y-6">
                <div class="flex flex-col gap-1">
                    <p class="font-medium text-sm">Shipping Service</p>
                    <p class="text-sm"><?php echo e($order->order_shippingservice); ?></p>
                </div>
                <div class="flex flex-col gap-1">
                    <p class="font-medium text-sm">Shipping Cost</p>
                    <p class="text-sm">IDR <?php echo e(number_format($order->order_shippingcost, 0, ',', '.')); ?></p>
                </div>
                <div class="flex flex-col gap-1">
                    <p class="font-medium text-sm">Total Payment</p>
                    <p class="text-sm">IDR <?php echo e(number_format($order->order_totalpayment, 0, ',', '.')); ?></p>
                </div>
                <div class="flex flex-col gap-1">
                    <p class="font-medium text-sm">Address</p>
                    <p class="text-sm"><?php echo e($order->order_address); ?></p>
                </div>
                <div class="flex flex-col gap-1">
                    <p class="font-medium text-sm text-error">Rejected Notes</p>
                    <p class="text-sm"><?php echo e($order->order_rejectednotes ? $order->order_rejectednotes : '-'); ?></p>
                </div>
            </div>
            <div class="flex flex-col gap-2 mt-6">
                <p class="font-medium text-sm">Order Details</p>
                <div class="flex flex-col">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $order->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex gap-6 items-center py-4 border-b border-gray-200">
                            <div class="rounded w-12 overflow-hidden">
                                <img src="<?php echo e(asset('storage/' . $orderDetail->product->product_img)); ?>"
                                    alt="Product Image">
                            </div>
                            <div class="block">
                                <p class="font-medium text-sm"><?php echo e($orderDetail->product->product_name); ?></p>
                                <p class="text-xs mt-1 mb-3"><?php echo e($orderDetail->product->category->category_name); ?></p>
                                <p class="text-sm">
                                    <span class="font-medium">Quantity</span>: <?php echo e($orderDetail->detail_quantity); ?>

                                    |
                                    <span class="font-medium">Total Price</span>: IDR
                                    <?php echo e(number_format($orderDetail->detail_totalprice, 0, ',', '.')); ?>

                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/livewire/user/payment/payment-details.blade.php ENDPATH**/ ?>