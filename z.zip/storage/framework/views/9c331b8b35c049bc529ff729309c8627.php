<div class="card bg-white">
    <div class="card-body">
        <div class="overflow-x-auto">
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Total Payment</th>
                        <th>Shipping Service</th>
                        <th>Address</th>
                        <th>Order Status</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php if($orders === null): ?>
                        <p class="text-sm text-error text-center">There is no order data.</p>
                    <?php else: ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="transition-all duration-300 cursor-pointer hover:bg-gray-200"
                                onclick="document.getElementById('my_modal_<?php echo e($order->order_id); ?>').showModal()">
                                <th><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($order->user->firstname); ?> <?php echo e($order->user->lastname); ?></td>
                                <td>IDR <?php echo e(number_format($order->order_totalpayment, 0, ',', '.')); ?></td>
                                <td><?php echo e($order->order_shippingservice); ?></td>
                                <td><?php echo e($order->order_address); ?></td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($order->order_status === 'Unpaid'): ?>
                                        <div class="badge badge-sm badge-error text-white">Unpaid</div>
                                    <?php elseif($order->order_status === 'Pending Approval'): ?>
                                        <div class="badge badge-sm badge-warning text-white">Pending</div>
                                    <?php elseif($order->order_status === 'Approved'): ?>
                                        <div class="badge badge-sm badge-info text-white">Waiting</div>
                                    <?php elseif($order->order_status === 'Rejected'): ?>
                                        <div class="badge badge-sm badge-error text-white">Rejected</div>
                                    <?php elseif($order->order_status === 'Retrieved'): ?>
                                        <div class="badge badge-sm badge-info text-white">Retrieved</div>
                                    <?php elseif($order->order_status === 'Sent'): ?>
                                        <div class="badge badge-sm badge-success text-white">Sent</div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                            </tr>
                            <dialog id="my_modal_<?php echo e($order->order_id); ?>" class="modal">
                                <div class="modal-box">
                                    <h3 class="font-bold text-lg"><?php echo e($order->order_totalpayment); ?></h3>
                                    <p class="py-4">Press ESC key or click the button below to close</p>
                                    <div class="modal-action">
                                        <form method="dialog">
                                            <!-- if there is a button in form, it will close the modal -->
                                            <button class="btn">Close</button>
                                        </form>
                                    </div>
                                </div>
                            </dialog>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/livewire/admin/order/order-list.blade.php ENDPATH**/ ?>