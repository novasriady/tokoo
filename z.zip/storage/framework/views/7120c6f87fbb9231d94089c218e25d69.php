<nav class="bg-white px-8 py-4 border-b border-gray-200">
    <div class="flex items-center justify-between">
        <p class="font-semibold">Welcome, Khen Cahyo</p>
        <div class="flex items-center gap-4">
            <p class="text-sm font-semibold">Khen Cahyo</p>
            <div class="avatar">
                <div class="w-10 rounded-full">
                    <img src="https://img.daisyui.com/images/stock/photo-1534528741775-53994a69daeb.jpg" />
                </div>
            </div>
        </div>
    </div>
</nav><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/components/admin/navbar.blade.php ENDPATH**/ ?>