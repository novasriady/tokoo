<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://kit.fontawesome.com/255fd51aa4.js" crossorigin="anonymous"></script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>Thrift - <?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <main>
        <div class="flex items-center justify-center h-screen">
            <?php echo $__env->yieldContent('content'); ?>
        </div> 
    </main>   
</body>
</html><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/layouts/auth.blade.php ENDPATH**/ ?>