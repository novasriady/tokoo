<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex flex-col">
    <h1 class="text-lg font-semibold">Dashboard</h1>
    <div class="text-sm breadcrumbs">
        <ul>
            <li>
                <a>Admin</a>
            </li>
            <li>
                <a>Dashboard</a>
            </li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/pages/admin/dashboard.blade.php ENDPATH**/ ?>