<nav class="px-12 py-2 bg-white">
    <div class="flex justify-between items-center">
        <p class="text-xl font-semibold">Thrift</p>
        <ul class="flex items-center gap-8">
            <li class="text-sm">
                <a href="<?php echo e(route('user.home')); ?>">Home</a>
            </li>
            <li class="text-sm">
                <a href="<?php echo e(route('user.product')); ?>">Products</a>
            </li>
        </ul>
        <div class="flex items-center gap-6">
            
            <div class="px-4 py-2 transition-all cursor-pointer duration-300 rounded-lg hover:bg-gray-200">
                <div class="flex items-center gap-4 cursor-pointer">
                    <p class="text-sm font-semibold">Khen Cahyo</p>
                    <div class="w-10 h-10 flex items-center justify-center bg-gray-200 rounded-full">
                        <span class="font-bold">K</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/components/user/navbar.blade.php ENDPATH**/ ?>