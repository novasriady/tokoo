<footer class="footer footer-center p-4 text-base-content">
    <aside>
        <p>Copyright © 2024 - All right reserved by Thrift App</p>
    </aside>
</footer><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/components/user/footer.blade.php ENDPATH**/ ?>