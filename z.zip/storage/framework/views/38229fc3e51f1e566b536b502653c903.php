<div class="flex flex-col gap-4">
    <div class="flex flex-col gap-2">
        <label class="label-text">Order Status</label>
        <select class="select select-sm select-bordered w-full" wire:model.live.debounce.300ms="orderStatus">
            <option value="" selected>Select Order Status</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
            <option value="Retrieved">Retrieved</option>
            <option value="Sent">Sent</option>
        </select>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['orderStatus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-error text-sm"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    <!--[if BLOCK]><![endif]--><?php if($orderStatus === 'Rejected'): ?>
        <div class="flex flex-col gap-2">
            <label class="label-text">Rejected Notes</label>
            <textarea class="textarea textarea-bordered" placeholder="Rejected Notes" wire:model.live.debounce.300ms="orderRejectedNotes"></textarea>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['orderRejectedNotes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-error text-sm"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <button class="btn btn-sm bg-gray-800 text-white" wire:click="updateOrderStatus">Update Order
        Status</button>
</div>
<?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/livewire/admin/order/update-order-form.blade.php ENDPATH**/ ?>