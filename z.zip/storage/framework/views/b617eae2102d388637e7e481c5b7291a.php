<div class="card bg-white shadow-md rounded-xl h-fit">
    <div class="card-body">
        <div class="flex flex-col gap-4">
            <div class="flex flex-col">
                <h1 class="text-lg font-semibold">Purchase Details</h1>
                <div class="divider mb-0 mt-1"></div>
            </div>
            <div class="flex flex-col gap-2">
                <label class="label-text">Quantity</label>
                <input type="number" placeholder="Order Quantity" class="input input-bordered input-sm w-full"
                    wire:model.live.debounce.300ms="quantity" required>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-error text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <p class="font-medium">Total Price: IDR <?php echo e(number_format($totalPrice, 0, ',', '.')); ?></p>
            <!--[if BLOCK]><![endif]--><?php if(!Auth::check()): ?>
                <p class="text-red-600 text-sm">You must login first to add products to the cart.</p>
            <?php else: ?>
                <?php
                    $isProductInCart = false;
                    if (isset($cart['order_details'])) {
                        $isProductInCart = collect($cart['order_details'])->contains(
                            'detail_product_id',
                            $product->product_id,
                        );
                    }
                ?>

                <!--[if BLOCK]><![endif]--><?php if($isProductInCart): ?>
                    <p class="text-green-600 text-sm">Product is already in the cart.</p>
                <?php else: ?>
                    <button class="btn btn-sm bg-gray-800 text-white" wire:click="addToCart">Add to Cart</button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        </div>
    </div>
</div>
<?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/livewire/user/purchase-details.blade.php ENDPATH**/ ?>