<div class="card bg-white shadow-md rounded-xl h-fit">
    <div class="card-body">
        <h1 class="font-semibold">Your Payment Data</h1>
        <div class="divider my-0"></div>
        <div class="overflow-x-auto">
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Shipping Service</th>
                        <th>Address</th>
                        <th>Total Payment</th>
                        <th>Order Status</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php if(count($orders) === 0): ?>
                        <p class="text-sm text-center text-error">No payment data available.</p>
                    <?php else: ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e($selectedOrderId === $order->order_id ? 'bg-gray-200' : ''); ?> transition-all duration-300 cursor-pointer hover:bg-gray-200" wire:click="getOrderById('<?php echo e($order->order_id); ?>')">
                                <th><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($order->order_shippingservice); ?></td>
                                <td><?php echo e($order->order_address); ?></td>
                                <td>IDR <?php echo e(number_format($order->order_totalpayment, 0, ',', '.')); ?></td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($order->order_status === 'Unpaid'): ?>
                                        <div class="badge badge-sm badge-error text-white">Unpaid</div>
                                    <?php elseif($order->order_status === 'Pending Approval'): ?>
                                        <div class="badge badge-sm badge-warning text-white">Pending
                                        </div>
                                    <?php elseif($order->order_status === 'Approved'): ?>
                                        <div class="badge badge-sm badge-info text-white">Waiting
                                        </div>
                                    <?php elseif($order->order_status === 'Rejected'): ?>
                                        <div class="badge badge-sm badge-error text-white">Rejected</div>
                                    <?php elseif($order->order_status === 'Retrieved'): ?>
                                        <div class="badge badge-sm badge-info text-white">Retrieved</div>
                                    <?php elseif($order->order_status === 'Sent'): ?>
                                        <div class="badge badge-sm badge-success text-white">Sent</div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/livewire/user/payment/payment-list.blade.php ENDPATH**/ ?>