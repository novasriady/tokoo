<?php $__env->startSection('title', 'Category'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-col gap-4">
        <div class="flex items-center justify-between">
            <div class="flex flex-col">
                <h1 class="text-lg font-semibold">Category</h1>
                <div class="text-sm breadcrumbs">
                    <ul>
                        <li>
                            <a>Admin</a>
                        </li>
                        <li>
                            <a>Category</a>
                        </li>
                    </ul>
                </div>
            </div>
            <button class="btn btn-sm bg-gray-800 text-white" onclick="addNewCategoryModal.showModal()">Add New</button>
        </div>
        <div class="card bg-white">
            <div class="card-body">
                <div class="overflow-x-auto">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($category->category_name); ?></td>
                                    <td><?php echo e($category->category_description); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('storage/' . $category->category_img)); ?>" alt="Category Img" class="w-16 rounded-md">
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('admin.deleteCategory', ['category_id' => $category->category_id])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-error text-white btn-sm">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <dialog id="addNewCategoryModal" class="modal">
        <div class="modal-box">
            <div class="flex items-center justify-between">
                <p class="font-semibold text-lg">Add New Category Form</p>
                <form method="dialog">
                    <button class="btn btn-sm">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </form>
            </div>
            <div class="divider"></div>
            <form action="<?php echo e(route('admin.storeCategory')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="flex flex-col gap-3">
                    <div class="flex flex-col gap-2">
                        <label class="label-text">Name</label>
                        <input type="text" placeholder="Category Name" name="category_name" class="input input-bordered input-sm w-full" required>
                    </div>
                    <div class="flex flex-col gap-2">
                        <label class="label-text">Description</label>
                        <input type="text" placeholder="Category Description" name="category_description" class="input input-bordered input-sm w-full" required>
                    </div>
                    <div class="flex flex-col gap-2">
                        <label class="label-text">Image</label>
                        <input type="file" accept="image/*" name="category_img" class="file-input file-input-bordered file-input-sm  w-full" required>
                    </div>
                </div>
                <div class="divider"></div>
                <div class="flex justify-end">
                    <button type="submit" class="btn btn-sm bg-gray-800 text-white">Create</button>
                </div>
            </form>
        </div>
    </dialog>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/soncahyo/Workspace/projects/khen-joki/thrift-app/resources/views/pages/admin/category.blade.php ENDPATH**/ ?>