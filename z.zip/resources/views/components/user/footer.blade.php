<footer class="footer footer-center p-4 text-base-content">
    <aside>
        <p>Copyright © 2024 - All right reserved by Thrift App</p>
    </aside>
</footer>