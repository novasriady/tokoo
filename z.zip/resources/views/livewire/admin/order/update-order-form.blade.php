<div class="flex flex-col gap-4">
    <div class="flex flex-col gap-2">
        <label class="label-text">Order Status</label>
        <select class="select select-sm select-bordered w-full" wire:model.live.debounce.300ms="orderStatus">
            <option value="" selected>Select Order Status</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
            <option value="Retrieved">Retrieved</option>
            <option value="Sent">Sent</option>
        </select>
        @error('orderStatus')
            <span class="text-error text-sm">{{ $message }}</span>
        @enderror
    </div>
    @if ($orderStatus === 'Rejected')
        <div class="flex flex-col gap-2">
            <label class="label-text">Rejected Notes</label>
            <textarea class="textarea textarea-bordered" placeholder="Rejected Notes" wire:model.live.debounce.300ms="orderRejectedNotes"></textarea>
            @error('orderRejectedNotes')
                <span class="text-error text-sm">{{ $message }}</span>
            @enderror
        </div>
    @endif
    <button class="btn btn-sm bg-gray-800 text-white" wire:click="updateOrderStatus">Update Order
        Status</button>
</div>
