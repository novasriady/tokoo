@extends('layouts.user')

@section('title', 'Product')

@section('content')
    <livewire:user.product-list />
@endsection